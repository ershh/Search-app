package com.example.searchApp.search;

public class Listing {
    
    public String id;
    public double price;
    public String title;

    public Listing (String id, double price, String title)
    {
    	this.id = id;
    	this.price = price;
    	this.title = title;
    }

}
